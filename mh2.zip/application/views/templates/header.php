<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href = "<?php echo base_url(); ?>assets/css/mh2style.css" rel = "stylesheet" type = "text/css">
    <link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>

  <div class="container-fluid">
            <div class="row" style="background-color: #53718e;">

        <div id="blackRow" style="height: 80px; background-color: #000000 !important;">
        <p>&nbsp;</p>
        </div>
</div>
</div>
<!-- body container starts here -->
<div class="container-fluid mx-auto">
            <div class="row">
                <div class="col-md-4 col-xl-3 col-lg-4 col-sm-12 col-xs-12">