<p>&nbsp;</p>
<div class="mx-auto">
<p>&nbsp;</p>
                    <a href="<?php echo base_url(); ?>">
                        <img src="<?php echo base_url(); ?>/assets/images/mh2_logo.png" alt="mh2 media logo." class="hide4-mobile img-fluid" /></a>
                    <img src="<?php echo base_url(); ?>/assets/images/mh2_logo.png" alt="mh2 media logo." border="0" class="show4-mobile img-fluid"/>
                    <p>&nbsp;</p>
                    <h3>2.0 coming soon ...</h3>
<p>we're busy working on a new site. check back soon.</p>
                 </div>
